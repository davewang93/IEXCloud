.. _crypto:

Cryptocurrency
==============

.. _crypto.contents:

.. contents::
    :depth: 2

.. _crypto.book:

Cryptocurrency Book
-------------------

.. autofunction:: iexfinance.crypto.get_crypto_book

.. _crypto.price:

Cryptocurrency Price
--------------------

.. autofunction:: iexfinance.crypto.get_crypto_price


.. _crypto.quote:

Cryptocurrency Quote
--------------------


.. autofunction:: iexfinance.crypto.get_crypto_quote