.. _about:


About
=====

.. _about.api-issues:

IEX API Issues
--------------

For issues the provider's API endpoints, email support@iexcloud.io. Further, the `IEX Status <https://twitter.com/iexstatus>`__ twitter account provides
updates about issues and service interruptions.

