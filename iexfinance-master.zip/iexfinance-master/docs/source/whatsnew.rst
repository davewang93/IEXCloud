.. _whatsnew:

**********
What's New
**********

New features, bug fixes, and improvements for each release.

.. include:: whatsnew/v0.5.1.txt

.. include:: whatsnew/v0.5.0.txt

.. include:: whatsnew/v0.4.3.txt

.. include:: whatsnew/v0.4.2.txt

.. include:: whatsnew/v0.4.1.txt

.. include:: whatsnew/v0.4.0.txt

.. include:: whatsnew/v0.3.5.txt

.. include:: whatsnew/v0.3.4.txt

.. include:: whatsnew/v0.3.3.txt

.. include:: whatsnew/v0.3.2.txt

.. include:: whatsnew/v0.3.1.txt

.. include:: whatsnew/v0.3.0.txt
