.. _apidata:

.. currentmodule:: iexfinance.apidata

API System Metadata
===================


.. contents:: Endpoints
    :depth: 2


.. _apidata.status:

Status
------

.. autofunction:: iexfinance.apidata.get_api_status
